from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import random
import requests
import os
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this-in-production'  # Change this for production

# Get the directory where this script is located (for PythonAnywhere compatibility)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, 'database.db')

# Database helper functions
def get_db_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def get_user_by_username(username):
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    conn.close()
    return user

def get_user_by_id(user_id):
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (int(user_id),)).fetchone()
    conn.close()
    return user

# Weather API functions using Open-Meteo (free, no API key needed)
def get_coordinates(city_name):
    """Get coordinates from city name using Open-Meteo Geocoding API"""
    try:
        url = f"https://geocoding-api.open-meteo.com/v1/search?name={city_name}&count=1&language=id&format=json"
        response = requests.get(url, timeout=5)
        data = response.json()

        if 'results' in data and len(data['results']) > 0:
            return {
                'lat': data['results'][0]['latitude'],
                'lon': data['results'][0]['longitude'],
                'name': data['results'][0]['name']
            }
        return None
    except Exception as e:
        print(f"Error getting coordinates: {e}")
        return None

def get_weather_description(weathercode):
    """Convert WMO Weather Code to Indonesian description"""
    weather_codes = {
        0: "Cerah",
        1: "Cerah Sebagian",
        2: "Berawan Sebagian",
        3: "Berawan",
        45: "Berkabut",
        48: "Berkabut Tebal",
        51: "Gerimis Ringan",
        53: "Gerimis Sedang",
        55: "Gerimis Lebat",
        61: "Hujan Ringan",
        63: "Hujan Sedang",
        65: "Hujan Lebat",
        71: "Salju Ringan",
        73: "Salju Sedang",
        75: "Salju Lebat",
        80: "Hujan Rintik",
        81: "Hujan Rintik Sedang",
        82: "Hujan Rintik Lebat",
        95: "Badai Petir",
        96: "Badai Petir dengan Hujan Es",
        99: "Badai Petir dengan Hujan Es Lebat"
    }
    return weather_codes.get(weathercode, "Tidak Diketahui")

def get_weather_icon(weathercode):
    """Get Bootstrap Icon class for weather condition"""
    if weathercode == 0:
        return "bi-sun"
    elif weathercode in [1, 2]:
        return "bi-cloud-sun"
    elif weathercode == 3:
        return "bi-cloud"
    elif weathercode in [45, 48]:
        return "bi-cloud-fog"
    elif weathercode in [51, 53, 55, 61, 63, 65, 80, 81, 82]:
        return "bi-cloud-rain"
    elif weathercode in [71, 73, 75]:
        return "bi-snow"
    elif weathercode in [95, 96, 99]:
        return "bi-cloud-lightning-rain"
    else:
        return "bi-cloud"

def get_weather_forecast(lat, lon):
    """Get 3-day weather forecast using Open-Meteo API"""
    try:
        url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&daily=temperature_2m_max,temperature_2m_min,weathercode&timezone=Asia/Jakarta&forecast_days=3"
        response = requests.get(url, timeout=5)
        data = response.json()

        if 'daily' in data:
            forecasts = []
            days_indonesian = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu']

            for i in range(3):
                date_str = data['daily']['time'][i]
                date_obj = datetime.strptime(date_str, '%Y-%m-%d')
                day_name = days_indonesian[date_obj.weekday()]

                if i == 0:
                    day_label = "Hari Ini"
                elif i == 1:
                    day_label = "Besok"
                else:
                    day_label = "Lusa"

                weathercode = data['daily']['weathercode'][i]

                forecasts.append({
                    'date': date_obj.strftime('%d/%m/%Y'),
                    'day_name': day_name,
                    'day_label': day_label,
                    'temp_max': round(data['daily']['temperature_2m_max'][i]),
                    'temp_min': round(data['daily']['temperature_2m_min'][i]),
                    'weather_desc': get_weather_description(weathercode),
                    'weather_icon': get_weather_icon(weathercode)
                })

            return forecasts
        return None
    except Exception as e:
        print(f"Error getting weather: {e}")
        return None

# Routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/weather', methods=['POST'])
def weather():
    """API endpoint to get weather data"""
    city = request.form.get('city', '').strip()

    if not city:
        return jsonify({'error': 'Nama kota tidak boleh kosong'}), 400

    # Get coordinates
    coords = get_coordinates(city)
    if not coords:
        return jsonify({'error': f'Kota "{city}" tidak ditemukan'}), 404

    # Get weather forecast
    forecast = get_weather_forecast(coords['lat'], coords['lon'])
    if not forecast:
        return jsonify({'error': 'Gagal mengambil data cuaca'}), 500

    return jsonify({
        'city': coords['name'],
        'forecast': forecast
    })

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('quiz'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        nickname = request.form.get('nickname', '').strip()

        # Validation
        if not username or not password or not nickname:
            flash('Semua field harus diisi!', 'error')
            return redirect(url_for('register'))

        if len(username) < 3:
            flash('Username minimal 3 karakter!', 'error')
            return redirect(url_for('register'))

        if len(password) < 6:
            flash('Password minimal 6 karakter!', 'error')
            return redirect(url_for('register'))

        if password != confirm_password:
            flash('Password dan konfirmasi password tidak cocok!', 'error')
            return redirect(url_for('register'))

        conn = get_db_connection()

        # Check if username exists
        existing_user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        if existing_user:
            flash('Username sudah digunakan!', 'error')
            conn.close()
            return redirect(url_for('register'))

        # Check if nickname exists
        existing_nickname = conn.execute('SELECT * FROM users WHERE nickname = ?', (nickname,)).fetchone()
        if existing_nickname:
            flash('Nickname sudah digunakan!', 'error')
            conn.close()
            return redirect(url_for('register'))

        # Create user
        password_hash = generate_password_hash(password)
        conn.execute('INSERT INTO users (username, password_hash, nickname) VALUES (?, ?, ?)',
                     (username, password_hash, nickname))
        conn.commit()
        conn.close()

        flash('Registrasi berhasil! Silakan login.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('quiz'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        if not username or not password:
            flash('Username dan password harus diisi!', 'error')
            return redirect(url_for('login'))

        user = get_user_by_username(username)

        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['nickname'] = user['nickname']
            flash(f'Selamat datang, {user["nickname"]}!', 'success')
            return redirect(url_for('quiz'))
        else:
            flash('Username atau password salah!', 'error')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Anda telah logout.', 'success')
    return redirect(url_for('home'))

@app.route('/quiz')
def quiz():
    if 'user_id' not in session:
        flash('Silakan login terlebih dahulu!', 'error')
        return redirect(url_for('login'))

    # Get user's total score
    user = get_user_by_id(session['user_id'])

    # Get a random question
    conn = get_db_connection()
    questions = conn.execute('SELECT * FROM questions').fetchall()
    conn.close()

    if not questions:
        flash('Tidak ada pertanyaan tersedia!', 'error')
        return redirect(url_for('home'))

    question = random.choice(questions)

    return render_template('quiz.html', question=question, user=user)

@app.route('/submit_quiz', methods=['POST'])
def submit_quiz():
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401

    question_id = request.form.get('question_id')
    user_answer = request.form.get('answer')

    if not question_id or not user_answer:
        return jsonify({'error': 'Invalid data'}), 400

    # Convert to int to ensure proper type
    user_id = int(session['user_id'])
    question_id = int(question_id)

    conn = get_db_connection()

    # Get the question
    question = conn.execute('SELECT * FROM questions WHERE id = ?', (question_id,)).fetchone()

    if not question:
        conn.close()
        return jsonify({'error': 'Question not found'}), 404

    # Check answer
    is_correct = user_answer.upper() == question['correct_answer'].upper()
    score = 10 if is_correct else 0

    # Update user's total score
    if is_correct:
        conn.execute('UPDATE users SET total_score = total_score + ? WHERE id = ?',
                     (score, user_id))

    # Record quiz history
    conn.execute('INSERT INTO quiz_history (user_id, score) VALUES (?, ?)',
                 (user_id, score))

    conn.commit()

    # Get updated user info
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()

    conn.close()

    # Get correct answer text
    correct_option = question[f'option_{question["correct_answer"].lower()}']

    return jsonify({
        'correct': is_correct,
        'correct_answer': question['correct_answer'],
        'correct_text': correct_option,
        'score': score,
        'total_score': user['total_score']
    })

@app.route('/leaderboard')
def leaderboard():
    conn = get_db_connection()
    top_users = conn.execute('''
        SELECT nickname, total_score
        FROM users
        WHERE total_score > 0
        ORDER BY total_score DESC
        LIMIT 10
    ''').fetchall()
    conn.close()

    return render_template('leaderboard.html', top_users=top_users)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8001)
