import sqlite3
import os

# Get the directory where this script is located (for PythonAnywhere compatibility)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, 'database.db')

def init_database():
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    # Create users table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        nickname TEXT UNIQUE NOT NULL,
        total_score INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Create questions table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        topic TEXT NOT NULL,
        question TEXT NOT NULL,
        option_a TEXT NOT NULL,
        option_b TEXT NOT NULL,
        option_c TEXT NOT NULL,
        option_d TEXT NOT NULL,
        correct_answer TEXT NOT NULL
    )
    ''')

    # Create quiz_history table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS quiz_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        quiz_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        score INTEGER NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
    ''')

    # Check if questions already exist
    cursor.execute('SELECT COUNT(*) FROM questions')
    if cursor.fetchone()[0] == 0:
        # Populate questions - 15 questions across 4 topics
        questions = [
            # Pengembangan AI dalam Python (4 questions)
            ('Pengembangan AI dalam Python', 'Library Python mana yang paling populer untuk machine learning?',
             'NumPy', 'Scikit-learn', 'Pandas', 'Matplotlib', 'B'),
            ('Pengembangan AI dalam Python', 'Apa kepanjangan dari AI?',
             'Automatic Intelligence', 'Artificial Intelligence', 'Advanced Intelligence', 'Automated Information', 'B'),
            ('Pengembangan AI dalam Python', 'Framework deep learning yang dikembangkan oleh Google adalah?',
             'PyTorch', 'Keras', 'TensorFlow', 'Theano', 'C'),
            ('Pengembangan AI dalam Python', 'Algoritma machine learning mana yang digunakan untuk klasifikasi?',
             'Linear Regression', 'K-Means', 'Decision Tree', 'PCA', 'C'),

            # Computer Vision (4 questions)
            ('Computer Vision', 'Library Python untuk pemrosesan gambar adalah?',
             'NumPy', 'OpenCV', 'Pandas', 'Requests', 'B'),
            ('Computer Vision', 'Proses mengidentifikasi objek dalam gambar disebut?',
             'Image Segmentation', 'Object Detection', 'Image Classification', 'Image Enhancement', 'B'),
            ('Computer Vision', 'Format gambar mana yang mendukung transparansi?',
             'JPEG', 'PNG', 'BMP', 'GIF', 'B'),
            ('Computer Vision', 'CNN dalam computer vision adalah singkatan dari?',
             'Computer Neural Network', 'Convolutional Neural Network', 'Complex Neural Network', 'Cognitive Neural Network', 'B'),

            # NLP - Natural Language Processing (4 questions)
            ('NLP', 'NLP adalah singkatan dari?',
             'Natural Language Processing', 'Neural Language Programming', 'Network Language Protocol', 'New Language Processing', 'A'),
            ('NLP', 'Library Python untuk NLP yang populer adalah?',
             'OpenCV', 'NLTK', 'NumPy', 'Matplotlib', 'B'),
            ('NLP', 'Proses memecah teks menjadi kata-kata disebut?',
             'Stemming', 'Lemmatization', 'Tokenization', 'Parsing', 'C'),
            ('NLP', 'Model bahasa besar (Large Language Model) seperti GPT menggunakan arsitektur?',
             'RNN', 'CNN', 'Transformer', 'LSTM', 'C'),

            # Implementasi Model AI (3 questions)
            ('Implementasi Model AI', 'Format file untuk menyimpan model machine learning adalah?',
             '.txt', '.pkl atau .h5', '.jpg', '.csv', 'B'),
            ('Implementasi Model AI', 'Proses menggunakan model yang sudah dilatih untuk prediksi disebut?',
             'Training', 'Inference', 'Validation', 'Testing', 'B'),
            ('Implementasi Model AI', 'Framework web Python yang cocok untuk deploy model AI adalah?',
             'Django atau Flask', 'React', 'Angular', 'Vue.js', 'A'),
        ]

        cursor.executemany('''
        INSERT INTO questions (topic, question, option_a, option_b, option_c, option_d, correct_answer)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', questions)

    conn.commit()
    conn.close()
    print("Database initialized successfully!")
    print("15 quiz questions added across 4 AI topics")

if __name__ == '__main__':
    init_database()
